FGV APEX — EAESP 2027.1 · FINAL POLISHED
==========================================
Plataforma local/PWA de treino adaptativo.

O QUE FOI REVISADO
- banco autoral expandido;
- domínio por microtópico;
- prioridade por fraqueza + recência;
- revisão espaçada;
- missão diária;
- sessão adaptativa;
- diagnóstico de padrões de erro;
- modo simulado;
- redação e matemática discursiva;
- analytics;
- modo foco com timer;
- atalhos de teclado;
- backup/importação local;
- PWA/offline;
- layout iPhone + PC.

IMPORTANTE
Questões são AUTORAIS e não oficiais da FGV. Use o edital e as provas oficiais da FGV como fonte de referência do processo seletivo.

INSTALAÇÃO NO IPHONE
1. Publique os arquivos em um endereço HTTPS.
2. Abra no Safari.
3. Compartilhar → Adicionar à Tela de Início.

DADOS
O progresso é salvo no navegador. Faça backup regularmente em Perfil → Exportar backup.
